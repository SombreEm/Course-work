document.addEventListener("DOMContentLoaded", () => {
    let vantaEffect = null;
    function initVanta() {
        const isLight = document.body.classList.contains("light-theme");

        if (!vantaEffect) {
            vantaEffect = VANTA.GLOBE({
                el: "#intro",
                mouseControls: true,
                touchControls: true,
                gyroControls: false,
                minHeight: 200.00,
                minWidth: 200.00,
                scale: 1.00,
                scaleMobile: 1.00,
                color: isLight ? 0xe1d143 : 0x843854, 
                backgroundColor: isLight ? 0x98a283 : 0x21212f, 
            });
        } else {
            vantaEffect.setOptions({
                color: isLight ? 0xe1d143 : 0x843854,
                backgroundColor: isLight ? 0x98a283 : 0x21212f,
            });
        }
    }
    const themeButton = document.getElementById("light-theme-btn");
    if (themeButton) {
        themeButton.addEventListener("click", function () {
            document.body.classList.toggle("light-theme");
            if (document.body.classList.contains("light-theme")) {
                localStorage.setItem("theme", "light-theme");
            } else {
                localStorage.removeItem("theme");
            }
            initVanta();
        });
    } else {
        console.error("Ошибка: Кнопка переключения темы не найдена!");
    }
    if (localStorage.getItem("theme") === "light-theme") {
        document.body.classList.add("light-theme");
    }
    initVanta();
});